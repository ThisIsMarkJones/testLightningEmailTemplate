# Test Lightning Email Template (v2)

An LWC for previewing and sending test emails from **Lightning (SFX) email templates**. It works with any object a template is related to (standard or custom), not only Case.

## What it does

1. **Choose a template.** You can filter the list by *Related object*. On a record page the filter starts on that page's object.
2. **Choose the record to merge.** You can do this in one of two ways:
   - **Search.** A `lightning-record-picker` for the template's object searches the name field (CaseNumber, Name, etc.) and a secondary field such as Subject, Email or StageName.
   - **Paste Id or URL.** Paste a 15- or 18-character Id, or copy the record's Lightning or Classic URL. The component checks that the record exists, that you can see it, and that it belongs to the template's object.
   - On a record page, or when a Flow passes in `recordId`, the current record is selected for you if it matches the template's object.
3. **Optional recipient record** (Contact, Lead or User). This fills `{{{Recipient.*}}}` merge fields. If you leave it blank, the component uses the record's `ContactId` when the object has one (for example Case).
4. **Preview.** This renders the subject, the HTML body and the plain-text body. It also shows which records were merged and flags any `{{{…}}}` tags left unresolved.
5. **Send test email** to up to 10 addresses. The address defaults to your own email.

## How rendering works

`Messaging.renderStoredEmailTemplate(templateId, whoId, whatId, METADATA_ONLY, false)` renders the template:

| Template's related object | whoId | whatId |
|---|---|---|
| Contact / Lead / User | the selected record | – |
| Any other object | the recipient record you chose, otherwise the record's `ContactId`, otherwise none | the selected record |

The rendered subject, body and attachments are copied into a **new** `SingleEmailMessage` that goes only to the addresses you enter. Because of this, no Contact/Lead/User target is needed, nothing is sent to the merged records, no activity is logged, and the template's usage count doesn't change.

## Deploy

```bash
sf project deploy start --source-dir force-app
sf org assign permset --name Email_Template_Tester   # Apex class access
sf apex run test --class-names EmailTestControllerTest --result-format human
npm install && npm run test:unit                      # LWC Jest tests
```

You need API 60.0 or later for `lightning-record-picker`. The project uses 62.0.

## Files

```
force-app/main/default/
  classes/EmailTestController.cls          Apex controller
  classes/EmailTestControllerTest.cls      Apex tests
  lwc/testLightningEmailTemplate/          Component, helper module and Jest tests
  permissionsets/Email_Template_Tester     Grants access to the controller
```

`OptionWrapper` is no longer used. You can delete it from the org if nothing else references it.

## Limitations

- The record picker only supports objects that the UI API supports. If an object can't be searched, use **Paste Id or URL**.
- The preview uses `lightning-formatted-rich-text`, which removes some styling. Send the test email to check the exact look.
- Emails sent to external addresses count toward the org's daily single-email limit. In sandboxes, *Setup → Deliverability* must be set to **All email**.
