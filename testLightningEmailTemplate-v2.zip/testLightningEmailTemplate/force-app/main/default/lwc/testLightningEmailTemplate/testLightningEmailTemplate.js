import { LightningElement, api, wire } from 'lwc';
import { getRecord, getFieldValue } from 'lightning/uiRecordApi';
import USER_ID from '@salesforce/user/Id';
import USER_EMAIL from '@salesforce/schema/User.Email';
import getEmailTemplates from '@salesforce/apex/EmailTestController.getEmailTemplates';
import getObjectInfo from '@salesforce/apex/EmailTestController.getObjectInfo';
import getRecordInfo from '@salesforce/apex/EmailTestController.getRecordInfo';
import renderTemplate from '@salesforce/apex/EmailTestController.renderTemplate';
import sendTestEmail from '@salesforce/apex/EmailTestController.sendTestEmail';
import { extractRecordId, reduceError, splitEmails, isValidEmail } from './recordIdUtils';

const MODE_SEARCH = 'search';
const MODE_PASTE = 'paste';
const ALL_OBJECTS = '__all__';
const NO_OBJECT = '__none__';
const PASTE_DEBOUNCE_MS = 400;
const RECIPIENT_OBJECTS = [
    { label: 'Contact', value: 'Contact', nameField: 'Name', secondaryField: 'Email' },
    { label: 'Lead', value: 'Lead', nameField: 'Name', secondaryField: 'Email' },
    { label: 'User', value: 'User', nameField: 'Name', secondaryField: 'Email' }
];

function pickerConfig(objectApiName, nameField, secondaryField, generation) {
    const config = {
        key: `${objectApiName}-${generation}`,
        objectApiName,
        matchingInfo: { primaryField: { fieldPath: nameField } },
        displayInfo: { primaryField: nameField }
    };
    if (secondaryField) {
        config.matchingInfo.additionalFields = [{ fieldPath: secondaryField }];
        config.displayInfo.additionalFields = [secondaryField];
    }
    return config;
}

export default class TestLightningEmailTemplate extends LightningElement {
    /** Set automatically on record pages; can be passed in from a Flow. */
    @api recordId;
    @api objectApiName;

    templates = [];
    templatesLoaded = false;
    objectFilter = ALL_OBJECTS;
    selectedTemplateId;

    objectInfo;
    recordMode = MODE_SEARCH;
    selectedRecordId;
    pastedValue = '';
    pastedRecord;
    pastedError;
    pickerGeneration = 0;

    recipientObject = 'Contact';
    recipientRecordId;

    recipientEmails = '';
    emailEdited = false;

    preview;
    isLoading = false;
    status;

    _pasteTimer;
    _requestToken = 0;

    // ------------------------------------------------------------------
    // Wires
    // ------------------------------------------------------------------

    @wire(getEmailTemplates)
    wiredTemplates({ data, error }) {
        if (data) {
            this.templates = data;
            this.templatesLoaded = true;
            // On a record page, start filtered to that page's object if it has templates.
            if (this.objectApiName && data.some((t) => t.objectApiName === this.objectApiName)) {
                this.objectFilter = this.objectApiName;
            }
        } else if (error) {
            this.templatesLoaded = true;
            this.setError(error);
        }
    }

    @wire(getRecord, { recordId: USER_ID, fields: [USER_EMAIL] })
    wiredUser({ data }) {
        if (data && !this.emailEdited && !this.recipientEmails) {
            this.recipientEmails = getFieldValue(data, USER_EMAIL) || '';
        }
    }

    // ------------------------------------------------------------------
    // Getters
    // ------------------------------------------------------------------

    get objectFilterOptions() {
        const labels = new Map();
        let hasUnrelated = false;
        this.templates.forEach((t) => {
            if (t.objectApiName) {
                labels.set(t.objectApiName, t.objectLabel || t.objectApiName);
            } else {
                hasUnrelated = true;
            }
        });
        const options = [...labels.entries()]
            .map(([value, label]) => ({ value, label }))
            .sort((a, b) => a.label.localeCompare(b.label));
        if (hasUnrelated) {
            options.push({ value: NO_OBJECT, label: 'No related object' });
        }
        return [{ value: ALL_OBJECTS, label: `All objects (${this.templates.length})` }, ...options];
    }

    get templateOptions() {
        return this.filteredTemplates.map((t) => ({
            value: t.value,
            label: this.objectFilter === ALL_OBJECTS && t.objectLabel ? `${t.label} · ${t.objectLabel}` : t.label,
            description: t.description
        }));
    }

    get filteredTemplates() {
        if (this.objectFilter === ALL_OBJECTS) {
            return this.templates;
        }
        if (this.objectFilter === NO_OBJECT) {
            return this.templates.filter((t) => !t.objectApiName);
        }
        return this.templates.filter((t) => t.objectApiName === this.objectFilter);
    }

    get noTemplates() {
        return this.templatesLoaded && this.templates.length === 0;
    }

    get selectedTemplate() {
        return this.templates.find((t) => t.value === this.selectedTemplateId);
    }

    get templateHasNoObject() {
        return this.selectedTemplate && !this.selectedTemplate.objectApiName;
    }

    get recordModeOptions() {
        const plural = this.objectInfo ? this.objectInfo.pluralLabel : 'records';
        return [
            { label: `Search ${plural}`, value: MODE_SEARCH },
            { label: 'Paste Id or URL', value: MODE_PASTE }
        ];
    }

    get isSearchMode() {
        return this.recordMode === MODE_SEARCH;
    }

    get canSearch() {
        return this.objectInfo && this.objectInfo.nameField && this.objectInfo.nameField !== 'Id';
    }

    get recordLabel() {
        return this.objectInfo ? `${this.objectInfo.label} to merge` : 'Record to merge';
    }

    get searchPlaceholder() {
        if (!this.objectInfo) {
            return '';
        }
        const secondary = this.objectInfo.secondaryField ? ` or ${this.objectInfo.secondaryField}` : '';
        return `Search by ${this.objectInfo.nameField}${secondary}…`;
    }

    /** Single-item array keyed by object + generation so the picker is rebuilt when the object changes. */
    get recordPickers() {
        if (!this.canSearch) {
            return [];
        }
        const { apiName, nameField, secondaryField } = this.objectInfo;
        return [pickerConfig(apiName, nameField, secondaryField, this.pickerGeneration)];
    }

    get showRecipientSection() {
        return this.objectInfo && !this.objectInfo.isRecipientType;
    }

    get recipientObjectOptions() {
        return RECIPIENT_OBJECTS.map(({ label, value }) => ({ label, value }));
    }

    get recipientPickers() {
        const config = RECIPIENT_OBJECTS.find((o) => o.value === this.recipientObject);
        return [pickerConfig(config.value, config.nameField, config.secondaryField, this.pickerGeneration)];
    }

    get recipientHelp() {
        return 'Optional. Fills {{{Recipient.…}}} merge fields. If blank, the record\'s Contact is used when it has one.';
    }

    get isReady() {
        if (!this.selectedTemplateId || this.isLoading) {
            return false;
        }
        return this.templateHasNoObject || !!this.selectedRecordId;
    }

    get disablePreview() {
        return !this.isReady;
    }

    get disableSend() {
        return !this.isReady || !this.recipientEmails;
    }

    get statusClass() {
        const theme = this.status && this.status.variant === 'success' ? 'slds-theme_success' : 'slds-theme_error';
        return `slds-notify slds-notify_alert slds-m-bottom_small ${theme}`;
    }

    get statusIcon() {
        return this.status && this.status.variant === 'success' ? 'utility:success' : 'utility:error';
    }

    get hasUnresolved() {
        return this.preview && this.preview.unresolvedMergeFields && this.preview.unresolvedMergeFields.length > 0;
    }

    get unresolvedList() {
        return this.hasUnresolved ? this.preview.unresolvedMergeFields.join(', ') : '';
    }

    get hasAttachments() {
        return this.preview && this.preview.attachmentCount > 0;
    }

    // ------------------------------------------------------------------
    // Template selection
    // ------------------------------------------------------------------

    handleObjectFilterChange(event) {
        this.objectFilter = event.detail.value;
        if (this.selectedTemplateId && !this.filteredTemplates.some((t) => t.value === this.selectedTemplateId)) {
            this.selectedTemplateId = undefined;
            this.resetRecordState();
            this.objectInfo = undefined;
        }
    }

    async handleTemplateChange(event) {
        const previousObject = this.objectInfo && this.objectInfo.apiName;
        this.selectedTemplateId = event.detail.value;
        this.status = undefined;
        this.preview = undefined;

        const template = this.selectedTemplate;
        const nextObject = template && template.objectApiName;

        // Same object as before: keep the chosen record, so you can flip between templates quickly.
        if (nextObject && nextObject === previousObject) {
            return;
        }

        this.resetRecordState();
        this.objectInfo = undefined;
        if (!nextObject) {
            return;
        }

        const token = ++this._requestToken;
        this.isLoading = true;
        try {
            const info = await getObjectInfo({ objectApiName: nextObject });
            if (token !== this._requestToken) {
                return;
            }
            this.objectInfo = info;
            this.recordMode = this.canSearch ? MODE_SEARCH : MODE_PASTE;
            this.pickerGeneration += 1;
            await this.prefillFromPageRecord(info, token);
        } catch (error) {
            this.setError(error);
        } finally {
            if (token === this._requestToken) {
                this.isLoading = false;
            }
        }
    }

    /** On a record page (or when a Flow passes recordId) preselect it if the template's object matches. */
    async prefillFromPageRecord(info, token) {
        if (!this.recordId) {
            return;
        }
        if (this.objectApiName && this.objectApiName !== info.apiName) {
            return;
        }
        try {
            const record = await getRecordInfo({ recordId: this.recordId });
            if (token === this._requestToken && record.objectApiName === info.apiName) {
                this.selectedRecordId = record.recordId;
            }
        } catch (e) {
            // Not fatal: the user can still pick a record manually.
        }
    }

    resetRecordState() {
        this.selectedRecordId = undefined;
        this.pastedValue = '';
        this.pastedRecord = undefined;
        this.pastedError = undefined;
        this.recipientRecordId = undefined;
        this.preview = undefined;
        clearTimeout(this._pasteTimer);
    }

    // ------------------------------------------------------------------
    // Record selection
    // ------------------------------------------------------------------

    handleRecordModeChange(event) {
        this.recordMode = event.detail.value;
        this.selectedRecordId = undefined;
        this.pastedValue = '';
        this.pastedRecord = undefined;
        this.pastedError = undefined;
        this.preview = undefined;
        this.pickerGeneration += 1;
    }

    handleRecordPicked(event) {
        this.selectedRecordId = event.detail.recordId || undefined;
        this.preview = undefined;
    }

    handlePasteChange(event) {
        this.pastedValue = event.detail.value;
        this.selectedRecordId = undefined;
        this.pastedRecord = undefined;
        this.pastedError = undefined;
        this.preview = undefined;
        clearTimeout(this._pasteTimer);
        // eslint-disable-next-line @lwc/lwc/no-async-operation
        this._pasteTimer = setTimeout(() => this.resolvePastedValue(), PASTE_DEBOUNCE_MS);
    }

    async resolvePastedValue() {
        const raw = this.pastedValue;
        if (!raw || !raw.trim()) {
            return;
        }
        const id = extractRecordId(raw);
        if (!id) {
            this.pastedError = 'That doesn\'t look like a Salesforce record Id or record URL.';
            return;
        }
        try {
            const record = await getRecordInfo({ recordId: id });
            if (raw !== this.pastedValue) {
                return; // user kept typing
            }
            if (this.objectInfo && record.objectApiName !== this.objectInfo.apiName) {
                this.pastedError = `That Id belongs to the ${record.objectLabel} object, but this template is for ${this.objectInfo.label} records.`;
                return;
            }
            this.pastedRecord = record;
            this.selectedRecordId = record.recordId;
        } catch (error) {
            if (raw === this.pastedValue) {
                this.pastedError = reduceError(error);
            }
        }
    }

    handleRecipientObjectChange(event) {
        this.recipientObject = event.detail.value;
        this.recipientRecordId = undefined;
        this.preview = undefined;
        this.pickerGeneration += 1;
    }

    handleRecipientPicked(event) {
        this.recipientRecordId = event.detail.recordId || undefined;
        this.preview = undefined;
    }

    // ------------------------------------------------------------------
    // Preview & send
    // ------------------------------------------------------------------

    handleEmailChange(event) {
        this.recipientEmails = event.detail.value;
        this.emailEdited = true;
        event.target.setCustomValidity('');
    }

    async handlePreview() {
        this.status = undefined;
        this.isLoading = true;
        try {
            this.preview = await renderTemplate(this.apexParams());
        } catch (error) {
            this.preview = undefined;
            this.setError(error);
        } finally {
            this.isLoading = false;
        }
    }

    async handleSend() {
        const input = this.template.querySelector('[data-id="emails"]');
        const emails = splitEmails(this.recipientEmails);
        const invalid = emails.filter((e) => !isValidEmail(e));
        if (input) {
            input.setCustomValidity(
                emails.length === 0
                    ? 'Enter at least one email address.'
                    : invalid.length
                      ? `Not a valid email: ${invalid.join(', ')}`
                      : ''
            );
            input.reportValidity();
        }
        if (emails.length === 0 || invalid.length) {
            return;
        }

        this.status = undefined;
        this.isLoading = true;
        try {
            const message = await sendTestEmail({ ...this.apexParams(), recipientEmails: emails.join(',') });
            this.status = { variant: 'success', message };
        } catch (error) {
            this.setError(error);
        } finally {
            this.isLoading = false;
        }
    }

    handleDismissStatus() {
        this.status = undefined;
    }

    apexParams() {
        return {
            templateId: this.selectedTemplateId,
            recordId: this.selectedRecordId || null,
            recipientRecordId: this.showRecipientSection ? this.recipientRecordId || null : null
        };
    }

    setError(error) {
        this.status = { variant: 'error', message: reduceError(error) };
    }

    disconnectedCallback() {
        clearTimeout(this._pasteTimer);
    }
}
