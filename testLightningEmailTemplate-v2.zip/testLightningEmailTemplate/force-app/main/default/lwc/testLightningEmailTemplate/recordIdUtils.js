/**
 * Pulls a Salesforce record Id out of whatever the user pasted:
 *   - a bare 15/18-character Id
 *   - a Lightning URL  (.../lightning/r/Case/500.../view)
 *   - a Classic URL    (.../500...  or  ...?id=500...)
 * Returns null when nothing Id-shaped is found. The server still validates it.
 */
const LIGHTNING_URL = /\/r\/[^/]+\/([a-zA-Z0-9]{15}(?:[a-zA-Z0-9]{3})?)(?=[/?#]|$)/;
const ID_PARAM = /[?&](?:id|recordId)=([a-zA-Z0-9]{15}(?:[a-zA-Z0-9]{3})?)(?=[&#]|$)/i;
const ID_TOKEN = /(?:^|[^a-zA-Z0-9])([a-zA-Z0-9]{18}|[a-zA-Z0-9]{15})(?=$|[^a-zA-Z0-9])/g;

export function extractRecordId(input) {
    const value = (input || '').trim();
    if (!value) {
        return null;
    }

    const lightning = value.match(LIGHTNING_URL);
    if (lightning) {
        return lightning[1];
    }

    const param = value.match(ID_PARAM);
    if (param) {
        return param[1];
    }

    // Real Ids always contain a digit; this skips words like "PlatformEventsX".
    for (const match of value.matchAll(ID_TOKEN)) {
        if (/\d/.test(match[1])) {
            return match[1];
        }
    }
    return null;
}

/** Normalises Apex / UI API / JS errors into one readable string. */
export function reduceError(error) {
    if (!error) {
        return 'Unknown error.';
    }
    if (Array.isArray(error)) {
        return error.map(reduceError).join(', ');
    }
    if (Array.isArray(error.body)) {
        return error.body.map((e) => e.message).join(', ');
    }
    if (error.body && typeof error.body.message === 'string') {
        return error.body.message;
    }
    if (typeof error.message === 'string') {
        return error.message;
    }
    return 'Unknown error.';
}

/** Splits a comma/semicolon/space separated list of addresses. */
export function splitEmails(value) {
    return (value || '')
        .split(/[,;\s]+/)
        .map((part) => part.trim())
        .filter(Boolean);
}

const EMAIL = /^[A-Za-z0-9._%+'-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/;
export function isValidEmail(value) {
    return EMAIL.test(value);
}
