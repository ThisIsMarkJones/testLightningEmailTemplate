import { createElement } from 'lwc';
import TestLightningEmailTemplate from 'c/testLightningEmailTemplate';
import getEmailTemplates from '@salesforce/apex/EmailTestController.getEmailTemplates';
import getObjectInfo from '@salesforce/apex/EmailTestController.getObjectInfo';
import getRecordInfo from '@salesforce/apex/EmailTestController.getRecordInfo';
import renderTemplate from '@salesforce/apex/EmailTestController.renderTemplate';
import sendTestEmail from '@salesforce/apex/EmailTestController.sendTestEmail';
import { getRecord } from 'lightning/uiRecordApi';
import { extractRecordId } from '../recordIdUtils';

jest.mock(
    '@salesforce/apex/EmailTestController.getEmailTemplates',
    () => {
        const { createApexTestWireAdapter } = require('@salesforce/sfdx-lwc-jest');
        return { default: createApexTestWireAdapter(jest.fn()) };
    },
    { virtual: true }
);
jest.mock('@salesforce/apex/EmailTestController.getObjectInfo', () => ({ default: jest.fn() }), { virtual: true });
jest.mock('@salesforce/apex/EmailTestController.getRecordInfo', () => ({ default: jest.fn() }), { virtual: true });
jest.mock('@salesforce/apex/EmailTestController.renderTemplate', () => ({ default: jest.fn() }), { virtual: true });
jest.mock('@salesforce/apex/EmailTestController.sendTestEmail', () => ({ default: jest.fn() }), { virtual: true });

const TEMPLATES = [
    { value: '00X1', label: 'Case Update', objectApiName: 'Case', objectLabel: 'Case' },
    { value: '00X2', label: 'Opp Won', objectApiName: 'Opportunity', objectLabel: 'Opportunity' },
    { value: '00X3', label: 'Generic', objectApiName: null }
];
const OPP_INFO = {
    apiName: 'Opportunity', label: 'Opportunity', pluralLabel: 'Opportunities',
    nameField: 'Name', secondaryField: 'StageName', isRecipientType: false
};
const OPP_ID = '006000000000001AAA';

const flush = () => new Promise((resolve) => setTimeout(resolve, 0));

function mount(props = {}) {
    const el = createElement('c-test-lightning-email-template', { is: TestLightningEmailTemplate });
    Object.assign(el, props);
    document.body.appendChild(el);
    getEmailTemplates.emit(TEMPLATES);
    getRecord.emit({ fields: { Email: { value: 'me@example.com' } } });
    return el;
}

const $ = (el, sel) => el.shadowRoot.querySelector(sel);
const $$ = (el, sel) => [...el.shadowRoot.querySelectorAll(sel)];
const comboboxByLabel = (el, label) => $$(el, 'lightning-combobox').find((c) => c.label === label);
const buttonByLabel = (el, label) => $$(el, 'lightning-button').find((b) => b.label === label);

async function chooseTemplate(el, id) {
    comboboxByLabel(el, 'Email template').dispatchEvent(new CustomEvent('change', { detail: { value: id } }));
    await flush();
    await flush();
}

afterEach(() => {
    while (document.body.firstChild) document.body.removeChild(document.body.firstChild);
    jest.clearAllMocks();
    jest.useRealTimers();
});

describe('extractRecordId', () => {
    it.each([
        ['500Dn00000AbCdEFGH', '500Dn00000AbCdEFGH'],
        ['  006000000000001  ', '006000000000001'],
        ['https://acme.lightning.force.com/lightning/r/Invoice__c/a015g00000XyZ12AAB/view', 'a015g00000XyZ12AAB'],
        ['https://acme.my.salesforce.com/500Dn00000AbCdE', '500Dn00000AbCdE'],
        ['https://acme.my.salesforce.com/apex/page?id=001000000000001AAA&x=1', '001000000000001AAA'],
        ['hello world', null],
        ['', null]
    ])('%s -> %s', (input, expected) => {
        expect(extractRecordId(input)).toBe(expected);
    });
});

describe('c-test-lightning-email-template', () => {
    it('lists templates with object labels and an object filter', async () => {
        const el = mount();
        await flush();
        const tpl = comboboxByLabel(el, 'Email template');
        expect(tpl.options.map((o) => o.label)).toEqual(['Case Update · Case', 'Opp Won · Opportunity', 'Generic']);

        const filter = comboboxByLabel(el, 'Related object');
        expect(filter.options.map((o) => o.value)).toEqual(['__all__', 'Case', 'Opportunity', '__none__']);
        filter.dispatchEvent(new CustomEvent('change', { detail: { value: 'Opportunity' } }));
        await flush();
        expect(comboboxByLabel(el, 'Email template').options).toEqual([
            { value: '00X2', label: 'Opp Won', description: undefined }
        ]);
    });

    it('defaults the recipient to the running user email', async () => {
        const el = mount();
        await flush();
        expect($(el, '[data-id="emails"]').value).toBe('me@example.com');
    });

    it('shows a record picker for the template object (not just Case)', async () => {
        getObjectInfo.mockResolvedValue(OPP_INFO);
        const el = mount();
        await chooseTemplate(el, '00X2');

        expect(getObjectInfo).toHaveBeenCalledWith({ objectApiName: 'Opportunity' });
        const pickers = $$(el, 'lightning-record-picker');
        expect(pickers[0].objectApiName).toBe('Opportunity');
        expect(pickers[0].matchingInfo).toEqual({
            primaryField: { fieldPath: 'Name' },
            additionalFields: [{ fieldPath: 'StageName' }]
        });
        // second picker is the optional recipient (Contact by default)
        expect(pickers[1].objectApiName).toBe('Contact');
        expect(buttonByLabel(el, 'Send test email').disabled).toBe(true);

        pickers[0].dispatchEvent(new CustomEvent('change', { detail: { recordId: OPP_ID } }));
        await flush();
        expect(buttonByLabel(el, 'Send test email').disabled).toBe(false);
    });

    it('accepts a pasted record URL and validates the object', async () => {
        jest.useFakeTimers();
        getObjectInfo.mockResolvedValue(OPP_INFO);
        getRecordInfo.mockResolvedValue({
            recordId: OPP_ID, objectApiName: 'Opportunity', objectLabel: 'Opportunity', name: 'Big Deal'
        });
        const el = mount();
        comboboxByLabel(el, 'Email template').dispatchEvent(new CustomEvent('change', { detail: { value: '00X2' } }));
        await Promise.resolve(); await Promise.resolve(); await Promise.resolve();

        $(el, 'lightning-radio-group').dispatchEvent(new CustomEvent('change', { detail: { value: 'paste' } }));
        await Promise.resolve();
        const input = $$(el, 'lightning-input').find((i) => i.label === 'Opportunity to merge');
        input.dispatchEvent(new CustomEvent('change', {
            detail: { value: `https://x.lightning.force.com/lightning/r/Opportunity/${OPP_ID}/view` }
        }));
        jest.advanceTimersByTime(500);
        await Promise.resolve(); await Promise.resolve(); await Promise.resolve();

        expect(getRecordInfo).toHaveBeenCalledWith({ recordId: OPP_ID });
        expect(el.shadowRoot.textContent).toContain('Opportunity: Big Deal');
        expect(buttonByLabel(el, 'Send test email').disabled).toBe(false);
    });

    it('rejects a pasted Id for the wrong object', async () => {
        jest.useFakeTimers();
        getObjectInfo.mockResolvedValue(OPP_INFO);
        getRecordInfo.mockResolvedValue({
            recordId: '001000000000001AAA', objectApiName: 'Account', objectLabel: 'Account', name: 'Acme'
        });
        const el = mount();
        comboboxByLabel(el, 'Email template').dispatchEvent(new CustomEvent('change', { detail: { value: '00X2' } }));
        await Promise.resolve(); await Promise.resolve(); await Promise.resolve();
        $(el, 'lightning-radio-group').dispatchEvent(new CustomEvent('change', { detail: { value: 'paste' } }));
        await Promise.resolve();
        $$(el, 'lightning-input')
            .find((i) => i.label === 'Opportunity to merge')
            .dispatchEvent(new CustomEvent('change', { detail: { value: '001000000000001AAA' } }));
        jest.advanceTimersByTime(500);
        await Promise.resolve(); await Promise.resolve(); await Promise.resolve();

        expect(el.shadowRoot.textContent).toContain('That Id belongs to the Account object');
        expect(buttonByLabel(el, 'Send test email').disabled).toBe(true);
    });

    it('preselects the record page record when the object matches', async () => {
        getObjectInfo.mockResolvedValue(OPP_INFO);
        getRecordInfo.mockResolvedValue({ recordId: OPP_ID, objectApiName: 'Opportunity', objectLabel: 'Opportunity', name: 'X' });
        const el = mount({ recordId: OPP_ID, objectApiName: 'Opportunity' });
        await flush();
        expect(comboboxByLabel(el, 'Related object').value).toBe('Opportunity');
        await chooseTemplate(el, '00X2');
        await flush();
        expect($(el, 'lightning-record-picker').value).toBe(OPP_ID);
    });

    it('previews and sends with the selected record and recipient', async () => {
        getObjectInfo.mockResolvedValue(OPP_INFO);
        renderTemplate.mockResolvedValue({
            subject: 'Won: Big Deal', htmlBody: '<p>Hi</p>', textBody: 'Hi',
            whatLabel: 'Opportunity: Big Deal', unresolvedMergeFields: ['{{{Recipient.FirstName}}}'], attachmentCount: 0
        });
        sendTestEmail.mockResolvedValue('Test email sent to me@example.com.');
        const el = mount();
        await chooseTemplate(el, '00X2');
        const [recordPicker, recipientPicker] = $$(el, 'lightning-record-picker');
        recordPicker.dispatchEvent(new CustomEvent('change', { detail: { recordId: OPP_ID } }));
        recipientPicker.dispatchEvent(new CustomEvent('change', { detail: { recordId: '003000000000001AAA' } }));
        await flush();

        buttonByLabel(el, 'Preview').click();
        await flush();
        expect(renderTemplate).toHaveBeenCalledWith({
            templateId: '00X2', recordId: OPP_ID, recipientRecordId: '003000000000001AAA'
        });
        expect(el.shadowRoot.textContent).toContain('Won: Big Deal');
        expect(el.shadowRoot.textContent).toContain('Unresolved merge fields: {{{Recipient.FirstName}}}');

        buttonByLabel(el, 'Send test email').click();
        await flush();
        expect(sendTestEmail).toHaveBeenCalledWith({
            templateId: '00X2', recordId: OPP_ID, recipientRecordId: '003000000000001AAA',
            recipientEmails: 'me@example.com'
        });
        expect(el.shadowRoot.textContent).toContain('Test email sent to me@example.com.');
    });

    it('allows templates with no related object without a record', async () => {
        const el = mount();
        await chooseTemplate(el, '00X3');
        expect(getObjectInfo).not.toHaveBeenCalled();
        expect($(el, 'lightning-record-picker')).toBeNull();
        expect(buttonByLabel(el, 'Send test email').disabled).toBe(false);
    });

    it('shows Apex errors inline', async () => {
        getObjectInfo.mockRejectedValue({ body: { message: 'Unsupported object type: Foo' } });
        const el = mount();
        await chooseTemplate(el, '00X1');
        expect(el.shadowRoot.textContent).toContain('Unsupported object type: Foo');
    });
});
